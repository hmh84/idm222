console.log('javascript.js loaded');
function toggleSideBar(){
    var element = document.getElementById("sideBar");
    element.classlist.toggle('toggleButton');
    console.log('toggle slide called');
}